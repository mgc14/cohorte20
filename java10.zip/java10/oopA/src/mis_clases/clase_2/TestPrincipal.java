package mis_clases.clase_2;

public class TestPrincipal {
	
	
	public static void main(String[] args) {
		ClasePadre cp=new ClasePadre(4565,"hola");
		cp.Visualizare();
		Clase_2 c2=new Clase_2(4521,"adios","clase2");
		c2.Visualizare();
		c2.visualivar2();
	}
}
