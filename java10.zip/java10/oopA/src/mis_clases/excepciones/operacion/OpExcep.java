package mis_clases.excepciones.operacion;

public class OpExcep extends Exception {
	
	
	public OpExcep(String mensaje) {
		super(mensaje);
	}
	

	
}
