package mis_clases.clase_publicas;

public class Clase_3 {
	int valor;

	public Clase_3() {
		
	}
	
	public int getValor() {
		return valor;
	}

	public void setValor(int valor) {
		this.valor = valor;
	}

	
	
}
