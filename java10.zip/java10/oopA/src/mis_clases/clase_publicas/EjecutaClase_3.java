package mis_clases.clase_publicas;

public class EjecutaClase_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Clase_3 c3 = new Clase_3();
		
		c3.setValor(2357);
		System.out.println(c3.valor);
	}

}
